package ��ӡ����;

import java.util.Scanner;

public class test04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.print("��Ҫ�������Σ�");
		
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int i,j,k;
		int m=(n+1)/2;
		for(i=1;i<=m;i++)
		{
			for(j=0;j<=m-i;j++)	
				{System.out.print(" ");}
			System.out.print("*");
			if(i==1) {System.out.println();continue;}
			for(k=0;k<2*i-3;k++)
			{
				System.out.print(" ");
				
			}
			System.out.print("*");
			System.out.println();
			
		}
		for(i=m-1;i>0;i--)
		{
		for(j=0;j<m-i+1;j++)
		{
			System.out.print(" ");
		}
		System.out.print("*");
		if(i==1)
		{
			System.out.println();
		continue;
		}
		for(k=1;k<=2*i-3;k++)
		{
			System.out.print(" ");
		}
		System.out.print("*");
		System.out.println();
		}


	}

}
