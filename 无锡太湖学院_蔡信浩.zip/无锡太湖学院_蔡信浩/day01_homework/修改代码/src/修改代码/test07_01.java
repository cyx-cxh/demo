package �޸Ĵ���;
/*public class test07_01 {
		public static void main(String[] args) {
			int a=0;
			System.out.println(a);
			{
				 int c = 20;
				System.out.println(c);
			}
			int c = 30;
			System.out.println(c);
		}
	}*/
	
	public class test07_01 {
		public static void main(String[] args) {
			int x = 2, y = 6;;
			{
				
				System.out.println("x is " + x);
				System.out.println("y is " + y);
			}
			y = x;
			System.out.println("x is " + x);
		}
	}
