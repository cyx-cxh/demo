package ��ӡõ�廨;

public class test05 {
	public static void main(String[] args) {
		
		System.out.println("  {@}");
		System.out.println("  /|\\");
System.out.println("   |");

	}
}
