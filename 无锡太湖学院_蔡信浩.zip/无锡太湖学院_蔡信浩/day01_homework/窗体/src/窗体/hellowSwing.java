package ����;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class hellowSwing {
	private static void createAndShowGUI() {
		// TODO Auto-generated method stub
		JFrame frame=new JFrame("hellowWorldSwing");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel label=new JLabel("hellow World!");
		frame.getContentPane().add(label);
		frame.pack();
		frame.setVisible(true);

	}
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				createAndShowGUI();
				
			}
		});
	}

}
