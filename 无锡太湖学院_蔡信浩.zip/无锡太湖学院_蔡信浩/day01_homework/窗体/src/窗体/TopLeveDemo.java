package ����;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;

public class TopLeveDemo {
	private static void createAndShowGUI() {
		// TODO Auto-generated method stub
		JFrame frame=new JFrame("TopLeveDemo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar greenMenuBar=new JMenuBar();
		greenMenuBar.setOpaque(true);
		greenMenuBar.setBackground(new Color(155, 164, 108));
		greenMenuBar.setPreferredSize(new Dimension(200, 20));
		JLabel yellowLable=new JLabel();
		yellowLable.setOpaque(true);
		yellowLable.setBackground(new Color(248, 210, 101));
		yellowLable.setPreferredSize(new Dimension(200, 180));
		frame.setJMenuBar(greenMenuBar);
		frame.getContentPane().add(yellowLable, BorderLayout.CENTER);
		frame.pack();
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				createAndShowGUI();
			}
		});
	}

}
