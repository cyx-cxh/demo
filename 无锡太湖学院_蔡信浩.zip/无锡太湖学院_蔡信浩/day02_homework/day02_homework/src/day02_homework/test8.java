package day02_homework;

import java.util.Scanner;

public class test8 {
	public static void main(String[] args) {
		int a;
		int b;
		System.out.print("����һ����a:");
		Scanner in=new Scanner(System.in);
		a=in.nextInt();
		System.out.print("����һ����b:");
		Scanner in1=new Scanner(System.in);
		b=in1.nextInt();
		int temp=a;
		a=b;
		b=temp;
		System.out.print("ת����a="+a+",b="+b);
	}

}
