package day02_homework;

public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=5;
double d=3.14;
short s=(short)(i+d);
System.out.print("s��ֵΪ��"+s);
	}

}
